package com.db.awmd.challenge.web;

import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.exception.DuplicateAccountIdException;
import com.db.awmd.challenge.exception.FundTransferException;
import com.db.awmd.challenge.service.AccountsService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v1/accounts")
@Slf4j
public class AccountsController {

	private final AccountsService accountsService;

	@Autowired
	public AccountsController(AccountsService accountsService) {
		this.accountsService = accountsService;
	}

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> createAccount(@RequestBody @Valid Account account) {
		log.info("Creating account {}", account);
        if(account.getBalance().get()== null)
        	return new ResponseEntity<>("Initial balance must be null.", HttpStatus.BAD_REQUEST);
        else if(account.getBalance().get().compareTo(BigDecimal.ZERO) <= 0 ){
        	return new ResponseEntity<>("Initial balance must be positive.", HttpStatus.BAD_REQUEST);
        }
		try {
			this.accountsService.createAccount(account);
		} catch (DuplicateAccountIdException daie) {
			return new ResponseEntity<>(daie.getMessage(), HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@GetMapping(path = "/{accountId}")
	public Account getAccount(@PathVariable String accountId) {
		log.info("Retrieving account for id {}", accountId);
		return this.accountsService.getAccount(accountId);
	}

	@RequestMapping(value = "/fund_transfer", method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE )
	@ResponseBody
	public ResponseEntity<Object> fundTransfer(HttpServletRequest request,
			@RequestBody @Valid FundTransferRequest transReq) {
		log.info("Fund transfer details {}", transReq);
		try {
			Account srcAccount = this.accountsService.getAccount(transReq.getFromAccount());
			if(srcAccount == null)
				return new ResponseEntity<>("Invalid From Account Id", HttpStatus.BAD_REQUEST);
			Account toAccount = this.accountsService.getAccount(transReq.getToAccount());
			if(toAccount == null)
				return new ResponseEntity<>("Invalid Target Account Id", HttpStatus.BAD_REQUEST);
			if(srcAccount.equals(toAccount))
				return new ResponseEntity<>("Can not transfer to same account", HttpStatus.BAD_REQUEST);
			this.accountsService.fundsTransfer(srcAccount, transReq.getToAccount(),
					new BigDecimal(transReq.getAmount()));
		} catch (FundTransferException e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<>(HttpStatus.OK);
	}

}
