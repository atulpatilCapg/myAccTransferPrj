package com.db.awmd.challenge.web;

import java.math.BigDecimal;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.service.NotificationService;

@Aspect
@Component
public class EmailNotificationAspect {
	@Autowired
	private NotificationService notificationService;

	@Around("@annotation(EmailNotify)")
	public Object notify(ProceedingJoinPoint pjp) throws Throwable {
		String transferDescription="";
		Object[] args = pjp.getArgs();
		Account account = (Account)args[0]; String toAcc = (String)args[1];BigDecimal amount = (BigDecimal) args[2];
		Boolean result = (Boolean) pjp.proceed();
		if (result) {// success 
			//logging
			transferDescription= "Success: Funds are transferred from Account: "+account.getAccountId()+"  to Account:"+toAcc+" with amount:"+amount;
		}else{
			//logging
			transferDescription= "FAILURE!!: Funds NOT transferred from Account: "+account.getAccountId()+"  to Account:"+toAcc+" with amount:"+amount;
		}
		notificationService.notifyAboutTransfer(account, transferDescription);
		return result;
	}
}
