package com.db.awmd.challenge.web;

import java.util.Objects;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;

//@ApiModel(description = "Funds transfer request ....")
public class FundTransferRequest {
	@JsonProperty("FromAccount")
	private String fromAccount;
	@JsonProperty("ToAccount")
	private String toAccount;
	@JsonProperty("TransferAmount")
	private String amount;

	// @ApiModelProperty(required = true, value = "This is Source Account Id ")
	@NotNull
	public String getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(String fromAccount) {
		this.fromAccount = fromAccount;
	}

	// @ApiModelProperty(required = true, value = "This is target Account Id ")
	@NotNull
	public String getToAccount() {
		return toAccount;
	}

	public void setToAccount(String toAccount) {
		this.toAccount = toAccount;
	}

	// @ApiModelProperty(required = true, value = "This is transfer Amount")
	@NotNull
	@Min(value = 0, message = "Initial balance must be positive.")
	@Pattern(regexp="^\\d{1,13}\\.\\d{1,2}$")
	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	@Override
	public int hashCode() {
		return Objects.hash(getFromAccount(), getToAccount(), getAmount());
	}

	@Override
	public boolean equals(Object o) {
		if (o == this) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		FundTransferRequest req = (FundTransferRequest) o;
		return Objects.equals(this.fromAccount, req.fromAccount) && Objects.equals(this.toAccount, req.toAccount)
				&& Objects.equals(this.amount, req.amount);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class FundTransferRequest {\n");
		sb.append("    fromAccount: ").append(fromAccount).append("\n");
		sb.append("    toAccount: ").append(toAccount).append("\n");
		sb.append("    amount: ").append(amount).append("\n");
		sb.append("}");
		return sb.toString();
	}

}
