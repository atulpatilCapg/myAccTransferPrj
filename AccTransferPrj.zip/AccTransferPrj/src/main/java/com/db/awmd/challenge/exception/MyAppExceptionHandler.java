package com.db.awmd.challenge.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class MyAppExceptionHandler extends ResponseEntityExceptionHandler {
	
	
	
	@ExceptionHandler({ Exception.class })
	protected ResponseEntity<Object> handleInvalidRequest(Exception e, WebRequest request) {
		//...................exception handler logic.............
		//construct error response body [corelationId , userId, .....]....
		
		Object body = new Object(); //object-to-json
		HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        
		return handleExceptionInternal(e, body, headers, HttpStatus.INTERNAL_SERVER_ERROR, request);
	}
}
