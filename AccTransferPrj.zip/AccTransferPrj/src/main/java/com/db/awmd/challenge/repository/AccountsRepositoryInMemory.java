package com.db.awmd.challenge.repository;

import java.math.BigDecimal;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.springframework.stereotype.Repository;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.exception.DuplicateAccountIdException;
import com.db.awmd.challenge.exception.FundTransferException;

@Repository
public class AccountsRepositoryInMemory implements AccountsRepository {

  private final Map<String, Account> accounts = new ConcurrentHashMap<>();
  
  private final ReadWriteLock lock = new ReentrantReadWriteLock(true);//fair locking , write priority
  private final Lock readLock = this.lock.readLock();
  private final Lock writeLock = this.lock.writeLock();
  //private volatile boolean reloadArray = true;
  
  @Override
  public void createAccount(Account account) throws DuplicateAccountIdException {
	  writeLock.lock();
	  try{  
		    Account previousAccount = accounts.putIfAbsent(account.getAccountId(), account);
		    if (previousAccount != null) {
		      throw new DuplicateAccountIdException(
		        "Account id " + account.getAccountId() + " already exists!");
		    } 
	}finally{
	    writeLock.unlock();   
	}
  }

  @Override
  public Account getAccount(String accountId) {
	  readLock.lock();
		try{//System.out.println("in repository getAccount()");
			return accounts.get(accountId);
		}finally{
		    readLock.unlock();
		}
    
  }

  @Override
  public void clearAccounts() {
	//reloadArray = false;
	  writeLock.lock();
		try{
			accounts.clear();
		}finally{
		    writeLock.unlock();   
		}
    
  }

	@Override
	public boolean transferAmount(String fromAccId, String toAccId, BigDecimal amount) {
		  writeLock.lock();
		  try{  
			  //validations
			  if(accounts.get(fromAccId) == null)
				  throw new FundTransferException("Invalid source Account Id :"+fromAccId);
			  if(accounts.get(toAccId) == null)
				  throw new FundTransferException("Invalid target Account Id "+toAccId);
			  //iterations 
			  accounts.forEach((id, acc) -> { 
				  if(id.equals(fromAccId)){ 
					  BigDecimal currentAmt =   acc.getBalance().get();
					  if(currentAmt.compareTo(amount) <= 0){//System.out.println("Over draft error");
						  throw new FundTransferException("Over Draft Facility is not supported ");}
					  
					  acc.getBalance().set(currentAmt.subtract(amount));
			     }
				  
				  if(id.equals(toAccId)){
					  BigDecimal targetAmt =  acc.getBalance().get();  
					  acc.getBalance().set(targetAmt.add(amount));
				  }
			  });
		
		  }finally{
			    writeLock.unlock();   
			}
		return true;
	}

}
