package com.db.awmd.challenge.exception;

public class FundTransferException extends RuntimeException {

  public FundTransferException(String message) {
    super(message);
  }
}
